# vault/urls.py

from django.urls import path
from . import views

# This list defines the URLs inside the vault app
urlpatterns = [
    # When Django hits this file, it sees the empty path ('') 
    # and calls the 'generator_view' function from vault/views.py
    path('', views.generator_view, name='generator'),
]