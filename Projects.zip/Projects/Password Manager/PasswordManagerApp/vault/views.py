from django.shortcuts import render
import random
import string

def generator_view(request):
    # --- Part 1: Password Generator Logic ---
    final_password = ""
    if request.GET.get('characterAmount'):
        length = int(request.GET.get('characterAmount', 12))
        
        characters = string.ascii_lowercase
        if request.GET.get('uppercaseCheck'):
            characters += string.ascii_uppercase
        if request.GET.get('numbersCheck'):
            characters += string.digits
        if request.GET.get('symbolsCheck'):
            characters += string.punctuation

        final_password = ''.join(random.choice(characters) for _ in range(length))

    # --- Part 2: Password Checker Logic ---
    check_results = None
    input_password = request.GET.get('passwordToCheck', '')

    if input_password:
        # Check specifications
        has_upper = any(c.isupper() for c in input_password)
        has_lower = any(c.islower() for c in input_password)
        has_digit = any(c.isdigit() for c in input_password)
        has_special = any(c in string.punctuation for c in input_password)
        length_ok = len(input_password) >= 12

        # Count how many specs are met
        score = sum([has_upper, has_lower, has_digit, has_special, length_ok])
        
        # Determine strength label
        if score == 5:
            strength = "Very Strong (Meets all specifications)"
            color = "#a6e3a1" # Green
        elif score >= 3:
            strength = "Medium (Missing some specifications)"
            color = "#f9e2af" # Yellow
        else:
            strength = "Weak (Does not meet basic specifications)"
            color = "#f38ba8" # Red

        check_results = {
            'password': input_password,
            'length': length_ok,
            'upper': has_upper,
            'lower': has_lower,
            'digit': has_digit,
            'special': has_special,
            'strength': strength,
            'color': color
        }

    context = {
        'finalPassword': final_password,
        'check_results': check_results,
    }
    
    return render(request, 'generator.html', context)