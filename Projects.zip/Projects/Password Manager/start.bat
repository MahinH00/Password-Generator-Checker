call venv\Scripts\activate
cd PasswordManagerApp
python manage.py runserver
